#!/bin/bash
fileScores="./tableau_scores.txt"
HighScores="./classement.txt"
#sed -i -e 's/.$//' ${fileScores}
#sed -i -e 's/$/0/' ${fileScores}
printf "" > ${fileScores}
printf "" > ${HighScores}
