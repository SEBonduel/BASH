#!/bin/bash
HighScores="./classement.txt"
cat ${HighScores}